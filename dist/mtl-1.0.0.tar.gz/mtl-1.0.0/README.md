# MTL : Mini tool to write HTML in Python

## ⬇️ Installation

```shell
pip install mtl
```
